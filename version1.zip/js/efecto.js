;
$(document).on("ready",efectosMisContactos);

function efectosMisContactos(){
	$("#principal div").fadeIn(2000);
}